#!/usr/bin/env python
# coding: utf-8

# In[2]:


import networkx as nx
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')
import numpy as np
cell_f_data = pd.read_excel("C:/Users/ASUS/jupter/over_mean_edges.xlsx")


# In[3]:


cell_f_data


# In[4]:


G = nx.DiGraph()


# In[5]:


edges = [edge for edge in zip(cell_f_data["header"],cell_f_data["target"])]
G.add_edges_from(edges)


# In[6]:


G.edges()


# In[7]:


# 节点排版布局-默认弹簧布局
pos = nx.spring_layout(G, seed=123)
edge_labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx_edge_labels(G, pos, font_size = 7 ,edge_labels = edge_labels)
nx.draw_networkx(G,pos = pos, with_labels=True)
# plt.figure(figsize = (15,15))
plt.title("cell_picture", fontsize=10)
plt.show()


# In[8]:


## 有方向的网络
from collections import defaultdict

def get_all_path(nodes_list,interacts_list,node_s,node_e): ## interacts_list是互作关系列表，构成是 p1-p2，第一列统称p1，第二列统称p2
    nodes_sum = len(nodes_list) ## 节点总数
    interacts_dict = defaultdict(list)
    for i in range(len(interacts_list)):
        interacts_dict[interacts_list[i].split('-')[0]].append(interacts_list[i].split('-')[1])
    masked = [False]*nodes_sum ## 将所有节点都标成False
    path = []
    def find_path(s,e,masked,path):
        ind_s = nodes_list.index(s) ## 起始节点的 索引
        masked[ind_s] = True ## 把起始节点处的标志改为 True
        path.append(s) ## 记录起始节点
        if s == e:  ## 如果起始节点和终止节点一样，那么直接输出path
            print(path)
        else:
            for p2 in interacts_dict[s]:
                ind_p2 = nodes_list.index(p2)
                if masked[ind_p2] == False:
                    find_path(s=p2,e=node_e,masked=masked,path=path)
        path.pop()
        ind_p = nodes_list.index(s)
        masked[ind_p] = False
    find_path(s=node_s,e=node_e,masked=masked,path=path)


# In[29]:


nodes_list = ["immature_B_cell", "DCSC", "IgA_B_cell", "Macrophage","Smooth_Muscle","Stem", "Paneth_like","IgG_B_cell","Fibroblast"]

## 默认网络节点间是有方向的，但是全部双向也就类似于没有方向
interacts_list = ['immature_B_cell-IgA_B_cell','immature_B_cell-Macrophage','immature_B_cell-IgG_B_cell',
                  'IgA_B_cell-immature_B_cell','IgA_B_cell-IgA_B_cell','IgA_B_cell-Macrophage',
                  'IgA_B_cell-Stem','IgA_B_cell-IgG_B_cell','Macrophage-immature_B_cell',
                  'Macrophage-Macrophage','Macrophage-Stem','Macrophage-Paneth_like','IgG_B_cell-immature_B_cell',
                  'IgG_B_cell-Macrophage','IgG_B_cell-IgG_B_cell','DCSC-immature_B_cell','DCSC-DCSC',
                  'DCSC-Macrophage','DCSC-Paneth_like','Paneth_like-immature_B_cell','Paneth_like-DCSC',
                  'Paneth_like-Macrophage','Paneth_like-Paneth_like','Paneth_like-IgG_B_cell','Stem-DCSC',
                  'Stem-Macrophage','Stem-Smooth_Muscle','Stem-IgG_B_cell','Smooth_Muscle-immature_B_cell',
                  'Smooth_Muscle-DCSC','Smooth_Muscle-Smooth_Muscle','Fibroblast-Paneth_like'] ## 网络中的 两两互作对
for i in range(0,9):
    print("//")
    print("immature_B_cell到",nodes_list[i],"的所有路径：")
    node_s = 'immature_B_cell' ## 起始节点
    node_e = nodes_list[i] ## 终止节点
    get_all_path(nodes_list=nodes_list,interacts_list=interacts_list,node_s=node_s,node_e=node_e)


# In[30]:


for i in range(0,9):
    print("//")
    print("DCSC到",nodes_list[i],"的所有路径：")
    node_s = 'DCSC' ## 起始节点
    node_e = nodes_list[i] ## 终止节点                             
    get_all_path(nodes_list=nodes_list,interacts_list=interacts_list,node_s=node_s,node_e=node_e)


# In[ ]:




