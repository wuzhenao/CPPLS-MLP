#!/usr/bin/env python
# coding: utf-8

# In[1]:


#step1:创建空图
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

#创建什么都没有的空图
G=nx.DiGraph() 
np.random.seed(1)

# 边的起点
start = ["immature_B_cell","DCSC","IgA_B_cell","Macrophage","Smooth_Muscle",
         "Stem","Paneth_like","IgG_B_cell","Fibroblast"]
# 边的重点
end = ["immature_B_cell","DCSC","IgA_B_cell","Macrophage","Smooth_Muscle",
         "Stem","Paneth_like","IgG_B_cell" ]
# 边的权重
value = []
# with open("C:/Users/ASUS/jupter/t_score1.txt","r") as f:
#     for line in f:
#          value.append(line.strip())
value = [0.316,0.136,0.482,0.6,0.195,0.23,0.232,0.438,
      0.405,0.424,0.283,0.431,0.231,0.078,0.733,0.245,
      0.494,0.277,0.42,0.447,0.16,0.739,0.335,0.479,
      0.478,0.092,0.334,0.698,0.21,0.485,0.479,0.19,
      0.357,0.504,0.096,0.034,0.435,0.187,0.299,0.326,
      0.063,0.476,0.282,0.383,0.59,0.297,0.253,0.432,
      0.501,0.64,0.276,0.395,0.296,0.235,0.378,0.362,
      0.384,0.201,0.309,0.402,0.22,0.167,0.205,0.441,
      0.193,0.098,0.308,0.24,0.344,0.256,0.392,0.309,
        ]
# 定义所有的边。
for i in range(0, len(start)):
    for j in range(0, len(end)):
        G.add_edges_from([(start[i], end[j])])
# 为所有的边进行赋值。
i = 0
for u,v in G.edges:
    if i < 72:
        G.add_edge(u, v, weight = value[i])
        i = i+1
        
# for (u, v, d) in G.edges(data=True) :
#     if d["weight"] > 0.347:
#         G.remove_edge(u, v)

# 为权重不同的边进行分类。
elarge = [(u, v) for (u, v, d) in G.edges(data=True) if (d["weight"] >= 0.347)]
esmall = [(u, v) for (u, v, d) in G.edges(data=True) if d["weight"] < 0.347]

# 画图。
pos = nx.spring_layout(G)

# nodes             定义节点的颜色：node_color = "b"

nx.draw_networkx_nodes(G, pos, node_size = 500)  
 
# edges
nx.draw_networkx_edges(G, pos, edgelist = elarge,
                       width = 2 , alpha = 1, edge_color = 'r',style = 'solid')

nx.draw_networkx_edges(G, pos, edgelist = esmall,
                       width = 1 , alpha = 0.5, edge_color = 'k', style = 'dashed')
# 画出边权值
edge_labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx_edge_labels(G, pos, font_size = 7 ,edge_labels = edge_labels)
 
# labels
nx.draw_networkx_labels(G, pos, font_size =7.5, font_family = "sans-serif")
# plt.axis("off")
plt.title("cell_picture", fontsize=10)
plt.show()


# In[3]:


# 得到细胞得分图的邻接矩阵。
cell_matrix = np.array(nx.adjacency_matrix(G).todense())
cell_matrix 


# In[4]:


G.edges.data()


# In[98]:


for i in range(0,8):
    for j in range(0,7):
        if cell_matrix[i][j] < 0.347:
            cell_matrix[i][j] = 0
        else:
            cell_matrix[i][j] = cell_matrix[i][j]
cell_matrix 


# In[2]:


#step1:创建空图
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

#创建什么都没有的空图
G=nx.DiGraph() 
np.random.seed(1)

# 边的起点
start = ["immature_B_cell","DCSC","IgA_B_cell","Macrophage","Smooth_Muscle",
         "Stem","Paneth_like","IgG_B_cell","Fibroblast"]
# 边的重点
end = ["immature_B_cell","DCSC","IgA_B_cell","Macrophage","Smooth_Muscle",
         "Stem","Paneth_like","IgG_B_cell","Fibroblast"]
# 边的权重
value = [0.   , 0.   , 0.482, 0.6  , 0.   , 0.   , 0.   , 0.438, 0.   ,
       0.405, 0.424, 0.   , 0.431, 0.   , 0.   , 0.733, 0.   , 0.   ,
       0.494, 0.   , 0.42 , 0.447, 0.   , 0.739, 0.   , 0.479, 0.   ,
       0.478, 0.   , 0.   , 0.698, 0.   , 0.485, 0.479, 0.   , 0.   ,
       0.357, 0.504, 0.   , 0.   , 0.435, 0.   , 0.   , 0.   , 0.   ,
       0.   , 0.476, 0.   , 0.383, 0.59 , 0.   , 0.   , 0.432, 0.   ,
       0.501, 0.64 , 0.   , 0.395, 0.   , 0.   , 0.378, 0.362, 0.   ,
       0.384, 0.   , 0.   , 0.402, 0.   , 0.   , 0.   , 0.441, 0.   ,
       0.   , 0.   , 0.   , 0.   , 0.   , 0.   , 0.392, 0.   , 0.   ]
# 定义所有的边。
for i in range(0, len(start)):
    for j in range(0, len(end)):
        G.add_edges_from([(start[i], end[j])])
# 为所有的边进行赋值。
i = 0
for u,v in G.edges:
    if i < 81:
        G.add_edge(u, v, weight = value[i])
    i = i+1

# 为权重不同的边进行分类。
elarge = [(u, v) for (u, v, d) in G.edges(data=True) if (d["weight"] >= 0.347)]


# 画图。
pos = nx.spring_layout(G)

# nodes             定义节点的颜色：node_color = "k"
nx.draw_networkx_nodes(G, pos, node_size = 600)   
# edges
nx.draw_networkx_edges(G, pos, edgelist = elarge,
                       width = 2 , alpha = 0.75,edge_color = 'k',style = 'dotted')

# 按pos所定位置画出节点,无标签无权值
nx.draw_networkx(G,  pos, node_size = 700, with_labels=None)
# 画出边权值
edge_labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx_edge_labels(G, pos, font_size = 7 ,edge_labels = edge_labels)
 
# labels
nx.draw_networkx_labels(G, pos, font_size = 7.5)
plt.axis("off")
# 图的标题。
plt.title("cell_picture", fontsize=10)
plt.show()


# In[3]:


import networkx as nx
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')
import numpy as np
cell_f_data = pd.read_excel("C:/Users/ASUS/jupter/over_mean_edges.xlsx")


# In[4]:


cell_f_data


# In[5]:


G = nx.DiGraph()


# In[6]:


edges = [edge for edge in zip(cell_f_data["header"],cell_f_data["target"])]

G.add_edges_from(edges)


# In[7]:


G.edges()


# In[8]:


import networkx as nx
# 节点排版布局-默认弹簧布局
pos = nx.spring_layout(G, seed=123)
edge_labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx_edge_labels(G, pos, font_size = 7 ,edge_labels = edge_labels)
nx.draw_networkx(G,pos = pos, with_labels=True)
# plt.figure(figsize = (15,15))
plt.title("cell_picture", fontsize=10)
plt.show()


# In[ ]:




