#!/usr/bin/env python
# coding: utf-8

# In[1]:


#step1:创建空图
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

np.random.seed(555)

# 创建一个有向图
G = nx.DiGraph()

# 添加节点
G.add_node("immature_B_cell")
G.add_node("DCSC")
G.add_node("IgA_B_cell")
G.add_node("Macrophage")
G.add_node("Smooth_Muscle")
G.add_node("Stem")
G.add_node("Paneth_like")
G.add_node("IgG_B_cell")
G.add_node("Fibroblast")

# 添加边和权值
G.add_edge("immature_B_cell","IgA_B_cell",weight=0.482)
G.add_edge("immature_B_cell", "Macrophage", weight=0.600)
G.add_edge("immature_B_cell", "IgG_B_cell", weight=0.438)
G.add_edge("DCSC", "immature_B_cell", weight=0.405)
G.add_edge("DCSC", "DCSC", weight=0.424)
G.add_edge("DCSC", "Macrophage", weight=0.431)
G.add_edge("DCSC", "Paneth_like", weight=0.733)
G.add_edge("IgA_B_cell", "immature_B_cell", weight=0.494)
G.add_edge("IgA_B_cell", "IgA_B_cell", weight=0.420)
G.add_edge("IgA_B_cell", "Macrophage", weight=0.447)
G.add_edge("IgA_B_cell", "Stem", weight=0.739)
G.add_edge("IgA_B_cell", "IgG_B_cell", weight=0.479)
G.add_edge("Macrophage", "immature_B_cell", weight=0.478)
G.add_edge("Macrophage", "Macrophage", weight=0.698)
G.add_edge("Macrophage", "Stem", weight=0.485)
G.add_edge("Macrophage", "Paneth_like", weight=0.479)
G.add_edge("Smooth_Muscle", "immature_B_cell", weight=0.357)
G.add_edge("Smooth_Muscle","DCSC", weight=0.504)
G.add_edge("Smooth_Muscle", "Smooth_Muscle", weight=0.435)
G.add_edge("Stem", "DCSC", weight=0.476)
G.add_edge("Stem", "Macrophage", weight=0.383)
G.add_edge("Stem", "Smooth_Muscle", weight=0.590)
G.add_edge("Stem", "IgG_B_cell", weight=0.432)
G.add_edge("Paneth_like", "immature_B_cell", weight=0.501)
G.add_edge("Paneth_like", "DCSC", weight=0.640)
G.add_edge("Paneth_like", "Macrophage", weight=0.395)
G.add_edge("Paneth_like", "Paneth_like", weight=0.378)
G.add_edge("Paneth_like", "IgG_B_cell", weight=0.362)
G.add_edge("IgG_B_cell", "immature_B_cell", weight=0.384)
G.add_edge("IgG_B_cell", "Macrophage", weight=0.402)
G.add_edge("IgG_B_cell", "IgG_B_cell", weight=0.441)
G.add_edge("Fibroblast", "Paneth_like", weight=0.392)

# 用edges存储G的所有边
edges = G.edges()


# In[2]:


# 画图。
pos = nx.spring_layout(G)

# nodes             定义节点的颜色：node_color = "k"
nx.draw_networkx_nodes(G, pos, node_size = 300)   
# edges
nx.draw_networkx_edges(G, pos, edges,
                       width = 2 , alpha = 0.75,edge_color = 'k',style = 'dotted')

# 按pos所定位置画出节点,无标签无权值
nx.draw_networkx(G,  pos, node_size = 700, with_labels=None)
# 画出边权值
edge_labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx_edge_labels(G, pos, font_size = 7 ,edge_labels = edge_labels)
 
# labels
nx.draw_networkx_labels(G, pos, font_size = 7.5)
plt.axis("off")
# 图的标题。
plt.title("cell_picture", fontsize=10)
plt.show()


# #Paneth_like到所有节点的路径及其路径和:

# In[3]:


mean = 0.347


# In[4]:


start_node = "Paneth_like"
end_node = "immature_B_cell"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[5]:


start_node = "Paneth_like"
end_node = "DCSC"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[6]:


start_node = "Paneth_like"
end_node = "IgA_B_cell"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[7]:


start_node = "Paneth_like"
end_node = "Macrophage"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[8]:


start_node = "Paneth_like"
end_node = "Smooth_Muscle"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[9]:


start_node = "Paneth_like"
end_node = "Stem"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[10]:


start_node = "Paneth_like"
end_node = "Paneth_like"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[11]:


start_node = "Paneth_like"
end_node = "IgG_B_cell"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[12]:


start_node = "Paneth_like"
end_node = "Fibroblast"

# 定义权值和的变量：
weight_total = 0
# 计算路径条数
all_path = nx.all_simple_paths(G, start_node, end_node)
print(start_node,"到",end_node,"一共有",len(list(all_path)),"条:")
print("                       ")


# 遍历起点和终点之间的所有路径
for path in nx.all_simple_paths(G, start_node, end_node):
    print(start_node,"到",end_node,"的路径上的节点个数为：",len(path))
    # 计算路径上的权值和
    path_weight = 0
    for i in range(len(path) - 1):
        path_weight += G[path[i]][path[i+1]]['weight']
    if len(path)-1 == 1:
        print(f"Path: {path}, weight: {path_weight}")
    else:
        for i in range(len(path) - 1):
            path_weight -= mean*pow(10,-i)
            # 输出路径和权值
        print(f"Path: {path}, weight: {path_weight}")
    print("                       ")
    weight_total += path_weight
print(weight_total)


# In[ ]:




